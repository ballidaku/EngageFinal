package com.midnight.engage.API;

import com.google.gson.annotations.SerializedName;

/**
 * Created by adi on 6/13/16.
 */
public class unfollowResponeLvl1 {
    @SerializedName("response")
    unfollowResponse response;

    public unfollowResponse getResponse() {
        return response;
    }
}
