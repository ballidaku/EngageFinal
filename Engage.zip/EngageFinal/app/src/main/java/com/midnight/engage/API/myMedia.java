package com.midnight.engage.API;

import com.google.gson.annotations.SerializedName;

/**
 * Created by adi on 6/3/16.
 */
public class myMedia {
    @SerializedName("response")
    ResponseMedia responseMedia;

    public ResponseMedia getResponseMedia() {
        return responseMedia;
    }
}


