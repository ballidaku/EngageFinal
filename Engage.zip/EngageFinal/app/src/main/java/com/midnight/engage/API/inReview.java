package com.midnight.engage.API;

import com.google.gson.annotations.SerializedName;

/**
 * Created by adi on 7/7/16.
 */
public class inReview {
    @SerializedName("inReview")
    String inReview;

    public String getInReview() {
        return inReview;
    }
}
