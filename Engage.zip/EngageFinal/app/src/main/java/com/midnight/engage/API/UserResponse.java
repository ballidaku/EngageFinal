package com.midnight.engage.API;

import com.google.gson.annotations.SerializedName;

/**
 * Created by adi on 6/5/16.
 */
public class UserResponse {
    @SerializedName("response")
    UserResponselvl2 responselvl2;

    public UserResponselvl2 getResponselvl2() {
        return responselvl2;
    }
}
